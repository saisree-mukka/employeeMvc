package com.cg.employee.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.employee.beans.Employee;


@Controller
public class URIController {
	@RequestMapping(value="/")
	public String getIndexPage() {
		return "index" ;
	}
	
	@RequestMapping(value="/add")
	public String getLogin() {
		return "add" ;
	}
	
	@RequestMapping(value="/display")
	public String getRegistration() {
		return "display" ;
	}
	
	@ModelAttribute("employee")
	public Employee getEmployeeDetails() {
		return new Employee() ;
	}
	
	@RequestMapping(value="/remove")
	public String getRemove() {
		return "remove" ;
	}
	
	@RequestMapping(value="/update")
	public String getUpdate() {
		return "update" ;
	}
	
	@RequestMapping(value="/updateNext")
	public String getUpdateNext() {
		return "updateNext" ;
	}
	
}
