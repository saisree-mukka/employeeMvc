package com.cg.employee.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employee.beans.Employee;
import com.cg.employee.exceptions.EmployeeNotFoundException;
import com.cg.employee.services.EmployeeService;

@Controller
public class EmployeeActionandController {
	@Autowired
	private EmployeeService employeeService ;
	
	@RequestMapping(value="/addEmployee")
	public ModelAndView addEmployee(@Valid @ModelAttribute("employee")Employee employee,BindingResult result) {
		
		try{
			if(result.hasErrors()) return new ModelAndView("add") ;
			employee=employeeService.addEmployee(employee) ;
		}
		catch(Exception e) {
			e.printStackTrace();
			return new ModelAndView("errorPage") ;
		}
		return new ModelAndView("addSuccessPage","employee",employee) ;
	}
	
//	@RequestMapping(value="/displayEmployee")
//	public ModelAndView displayEmployee(@Valid @ModelAttribute("employee")Employee employee,BindingResult result) {
//		
//		try{
//			if(result.hasErrors()) return new ModelAndView("display") ;
//			int id= employee.getId();
//			employee=employeeService.getEmployee(id) ;
//		}
//		catch(Exception e) {
//			e.printStackTrace();
//			return new ModelAndView("errorPage") ;
//		}
//		return new ModelAndView("displaySuccessPage","employee",employee) ;
//	}
	
	@RequestMapping(value="/displayEmployee",method=RequestMethod.POST)
	public ModelAndView displayEmployee(@RequestParam("id")int id) {
		
		try{
			Employee employee = employeeService.getEmployee(id) ;
			return new ModelAndView("displaySuccessPage","employee",employee) ;
		}
		catch(EmployeeNotFoundException e) {
			return new ModelAndView("display","errorMessage",e.getMessage()) ;
		}
		
	}
	
	@RequestMapping(value="/displayAll")
	public ModelAndView displayAllEmployee() {
		ArrayList<Employee>employeeList ;
		try{
			employeeList = employeeService.getAllEmployee() ;
		}
		catch(Exception e) {
			e.printStackTrace();
			return new ModelAndView("errorPage") ;
		}
		return new ModelAndView("displayAll","employeeList",employeeList) ;
	}
	
	
	@RequestMapping(value="/removeEmployee",method=RequestMethod.POST)
	public ModelAndView removeEmployee(@RequestParam("id")int id) {
		
		try{
			Employee employee = employeeService.getEmployee(id);
			employeeService.removeEmployee(id);
			return new ModelAndView("removeSuccessPage","employee",employee) ;
		}
		catch(EmployeeNotFoundException e) {
			return new ModelAndView("remove","errorMessage",e.getMessage()) ;
		}
		
	}
	
	@RequestMapping(value="/updateNext",method=RequestMethod.POST)
	public ModelAndView updateNext(@RequestParam("id")int id) {
		
		try{
			Employee employee = employeeService.getEmployee(id) ;
			return new ModelAndView("updateNext","employee",employee) ;
		}
		catch(EmployeeNotFoundException e) {
			return new ModelAndView("update","errorMessage",e.getMessage()) ;
		}
		
	}
	
	@RequestMapping(value="/updateEmployee",method=RequestMethod.POST)
	public ModelAndView updateEmployee(@ModelAttribute("employee")Employee employee,BindingResult result) {
		
		try{
			if(result.hasErrors()) return new ModelAndView("update") ;
			employee = employeeService.updateEmployee(employee) ;
			return new ModelAndView("updateSuccessPage","employee",employee) ;
		}
		catch(EmployeeNotFoundException e) {
			return new ModelAndView("update","errorMessage",e.getMessage()) ;
		}
		
	}
	
	
}
