package com.cg.employee.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.employee.beans.Employee;
import com.cg.employee.exceptions.EmployeeNotFoundException;
import com.cg.employee.exceptions.InvalidInputException;
import com.cg.employee.repo.EmployeeRepo;
@Component(value="employeeService")
public class EmployeeServicesImpl implements EmployeeService {
	@Autowired
	private EmployeeRepo employeeRepo ;
	@Override
	public Employee addEmployee(Employee employee) throws InvalidInputException {
		return employeeRepo.save(employee) ;
		
	}

	@Override
	public Employee getEmployee(int id) throws EmployeeNotFoundException {
		if(employeeRepo.findOne(id)==null)
			throw new EmployeeNotFoundException("Employee doesn't exist") ;
		return employeeRepo.findOne(id) ;
	}

	@Override
	public ArrayList<Employee> getAllEmployee() {
		return (ArrayList<Employee>) employeeRepo.findAll() ;
	}

	@Override
	public Employee updateEmployee(Employee employee) throws EmployeeNotFoundException{
		if(employeeRepo.findOne(employee.getId())==null)
			throw new EmployeeNotFoundException("Employee doesn't exist") ;
		return employeeRepo.save(employee) ;
	}

	@Override
	public void removeEmployee(int id) throws EmployeeNotFoundException {
		if(employeeRepo.findOne(id)==null)
			throw new EmployeeNotFoundException("Employee doesn't exist and hence cannot be removed") ;
		employeeRepo.delete(id);
		
	}

}
