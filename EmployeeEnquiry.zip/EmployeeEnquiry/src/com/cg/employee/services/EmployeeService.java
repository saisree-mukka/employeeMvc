package com.cg.employee.services;

import java.util.ArrayList;
import java.util.List;

import com.cg.employee.beans.Employee;
import com.cg.employee.exceptions.EmployeeNotFoundException;
import com.cg.employee.exceptions.InvalidInputException;

public interface EmployeeService {
	public Employee addEmployee(Employee employee) throws InvalidInputException ;
	public Employee getEmployee(int id) throws EmployeeNotFoundException ;
	public ArrayList<Employee> getAllEmployee() ;
	public Employee updateEmployee(Employee employee) throws EmployeeNotFoundException ;
	public void removeEmployee(int id) throws EmployeeNotFoundException ;
}
